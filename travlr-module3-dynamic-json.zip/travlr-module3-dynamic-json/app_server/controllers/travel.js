const trips = require('../data/trips.json');

const travel = (req, res) => {
  res.render('travel', {
    title: 'Travel - Travlr Getaways',
    pageHeading: 'Travel',
    trips
  });
};

module.exports = {
  travel
};

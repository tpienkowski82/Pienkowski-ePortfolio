const express = require('express');
const path = require('path');

const router = express.Router();
const ctrlTravel = require('../controllers/travel');

// Route for the original landing page.
router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/index.html'));
});

// Travel page rendered dynamically from trips.json by HBS.
router.get('/travel', ctrlTravel.travel);
router.get('/travel.html', ctrlTravel.travel);

module.exports = router;

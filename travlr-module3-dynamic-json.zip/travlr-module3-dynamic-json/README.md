# Travlr Getaways - Module Three

This project continues the Travlr Getaways full stack application by moving the Travel page from static HTML toward dynamic JSON data rendered through the Express MVC structure and Handlebars (HBS).

## Module Three Requirements Addressed

- Uses an Express customer-facing front-end architecture.
- Uses MVC structure with routes, controllers, views, and data.
- Uses HBS to render the Travel page dynamically.
- Uses `app_server/data/trips.json` as the source of trip data.
- Includes a route and controller for the Travel page.

## Important Files

```text
app.js
app_server/data/trips.json
app_server/controllers/travel.js
app_server/routes/index.js
app_server/views/travel.hbs
public/css/style.css
public/images/
```

## Run the Project

Install dependencies:

```bash
npm install
```

If PowerShell blocks npm, use:

```bash
npm.cmd install
```

Start the server:

```bash
npm start
```

Or, if using PowerShell:

```bash
npm.cmd start
```

Open the site:

```text
http://localhost:3000
```

Open the dynamic HBS Travel page:

```text
http://localhost:3000/travel
```

The Travel page is rendered from `trips.json` through the MVC pattern:

```text
Route -> Controller -> JSON Data -> HBS View
```

## GitHub Branch

For Module Three, push this work to a branch named:

```text
module3
```

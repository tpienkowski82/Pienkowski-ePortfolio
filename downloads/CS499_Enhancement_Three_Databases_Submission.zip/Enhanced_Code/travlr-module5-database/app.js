const express = require('express');
const path = require('path');
const hbs = require('hbs');

const indexRouter = require('./app_server/routes/index');
const apiRouter = require('./app_server/routes/api');

const app = express();

// Configure Handlebars view engine for the MVC application structure.
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Parse form and JSON requests before routing.
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// Register application routes before static files so dynamic HBS pages are used first.
app.use('/', indexRouter);
app.use('/api', apiRouter);

// Serve static assets such as CSS, images, and remaining HTML files from /public.
app.use(express.static(path.join(__dirname, 'public')));

// Catch 404 errors.
app.use((req, res) => {
  res.status(404).send('404: Page not found');
});

module.exports = app;

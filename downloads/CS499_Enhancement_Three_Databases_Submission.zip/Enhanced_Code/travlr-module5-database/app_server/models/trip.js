const REQUIRED_FIELDS = ['code', 'name', 'length', 'start', 'resort', 'perPerson', 'image', 'description'];

const parsePrice = (price) => Number.parseFloat(price) || 0;

const parseRating = (resort = '') => {
  const ratingMatch = resort.match(/(\d+)\s*stars?/i);
  return ratingMatch ? Number.parseInt(ratingMatch[1], 10) : 0;
};

const parseTripDays = (length = '') => {
  const dayMatch = length.match(/(\d+)\s*days?/i);
  return dayMatch ? Number.parseInt(dayMatch[1], 10) : 0;
};

const normalizeDescription = (description) => {
  if (Array.isArray(description)) {
    return description.map((item) => String(item).trim()).filter(Boolean);
  }

  if (typeof description === 'string') {
    return description.split('\n').map((item) => item.trim()).filter(Boolean);
  }

  return [];
};

const normalizeTrip = (trip) => ({
  code: String(trip.code || '').trim().toUpperCase(),
  name: String(trip.name || '').trim(),
  length: String(trip.length || '').trim(),
  start: String(trip.start || '').trim(),
  resort: String(trip.resort || '').trim(),
  perPerson: Number.parseFloat(trip.perPerson).toFixed(2),
  image: String(trip.image || '').trim(),
  description: normalizeDescription(trip.description)
});

const validateTrip = (trip, existingCodes = []) => {
  const errors = [];
  const normalizedTrip = normalizeTrip(trip);

  REQUIRED_FIELDS.forEach((field) => {
    const value = normalizedTrip[field];
    if ((Array.isArray(value) && value.length === 0) || value === '' || value === undefined || value === null) {
      errors.push(`${field} is required.`);
    }
  });

  if (!/^[A-Z0-9]{6,12}$/.test(normalizedTrip.code)) {
    errors.push('code must be 6 to 12 uppercase letters or numbers.');
  }

  if (existingCodes.includes(normalizedTrip.code)) {
    errors.push(`code ${normalizedTrip.code} already exists.`);
  }

  if (Number.isNaN(Number.parseFloat(trip.perPerson)) || Number.parseFloat(trip.perPerson) <= 0) {
    errors.push('perPerson must be a positive number.');
  }

  if (Number.isNaN(new Date(normalizedTrip.start).getTime())) {
    errors.push('start must be a valid date.');
  }

  if (parseTripDays(normalizedTrip.length) <= 0) {
    errors.push('length must include the number of days.');
  }

  if (parseRating(normalizedTrip.resort) <= 0) {
    errors.push('resort must include a star rating.');
  }

  return {
    isValid: errors.length === 0,
    errors,
    trip: normalizedTrip
  };
};

const toViewTrip = (trip) => ({
  ...trip,
  priceValue: parsePrice(trip.perPerson),
  rating: parseRating(trip.resort),
  tripDays: parseTripDays(trip.length),
  formattedStart: new Date(trip.start).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  })
});

module.exports = {
  REQUIRED_FIELDS,
  normalizeTrip,
  validateTrip,
  toViewTrip,
  parsePrice,
  parseRating,
  parseTripDays
};

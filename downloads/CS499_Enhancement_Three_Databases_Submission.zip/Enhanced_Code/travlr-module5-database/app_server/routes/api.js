const express = require('express');
const ctrlTrips = require('../controllers/apiTrips');

const router = express.Router();

router.get('/trips', ctrlTrips.listTrips);
router.get('/trips/:code', ctrlTrips.readTrip);
router.post('/trips', ctrlTrips.createTrip);
router.put('/trips/:code', ctrlTrips.updateTrip);
router.delete('/trips/:code', ctrlTrips.deleteTrip);

module.exports = router;

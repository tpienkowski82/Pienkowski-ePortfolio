const tripRepository = require('../database/tripRepository');
const { toViewTrip, parsePrice, parseRating, parseTripDays } = require('../models/trip');

/**
 * Build a searchable string for each trip. Combining the searchable fields once
 * keeps the filter logic readable and makes it easier to expand later.
 * @param {object} trip
 * @returns {string}
 */
const buildSearchText = (trip) => [
  trip.code,
  trip.name,
  trip.length,
  trip.start,
  trip.resort,
  trip.perPerson,
  ...(trip.description || [])
].join(' ').toLowerCase();

/**
 * Apply search, filter, and sort choices to the trip data.
 * This keeps the Milestone Three algorithms while reading records from the
 * Milestone Four database layer instead of directly from the JSON seed file.
 * @param {Array<object>} tripData
 * @param {object} query
 * @returns {object}
 */
const organizeTrips = (tripData, query) => {
  const searchTerm = (query.search || '').trim().toLowerCase();
  const maxPrice = Number.parseFloat(query.maxPrice);
  const minRating = Number.parseInt(query.minRating, 10);
  const sortBy = query.sortBy || 'start-asc';

  let filteredTrips = [...tripData];

  if (searchTerm) {
    filteredTrips = filteredTrips.filter((trip) => buildSearchText(trip).includes(searchTerm));
  }

  if (!Number.isNaN(maxPrice)) {
    filteredTrips = filteredTrips.filter((trip) => parsePrice(trip.perPerson) <= maxPrice);
  }

  if (!Number.isNaN(minRating)) {
    filteredTrips = filteredTrips.filter((trip) => parseRating(trip.resort) >= minRating);
  }

  const sortOptions = {
    'start-asc': (a, b) => new Date(a.start) - new Date(b.start),
    'price-asc': (a, b) => parsePrice(a.perPerson) - parsePrice(b.perPerson),
    'price-desc': (a, b) => parsePrice(b.perPerson) - parsePrice(a.perPerson),
    'name-asc': (a, b) => a.name.localeCompare(b.name),
    'rating-desc': (a, b) => parseRating(b.resort) - parseRating(a.resort),
    'length-asc': (a, b) => parseTripDays(a.length) - parseTripDays(b.length)
  };

  const sortFunction = sortOptions[sortBy] || sortOptions['start-asc'];
  filteredTrips.sort(sortFunction);

  const enhancedTrips = filteredTrips.map(toViewTrip);

  const summary = enhancedTrips.reduce((totals, trip) => {
    totals.totalPrice += trip.priceValue;
    totals.highestPrice = Math.max(totals.highestPrice, trip.priceValue);
    totals.highestRating = Math.max(totals.highestRating, trip.rating);
    return totals;
  }, {
    totalPrice: 0,
    highestPrice: 0,
    highestRating: 0
  });

  return {
    trips: enhancedTrips,
    searchTerm: query.search || '',
    maxPrice: query.maxPrice || '',
    minRating: query.minRating || '',
    sortBy,
    totalTrips: tripData.length,
    resultCount: enhancedTrips.length,
    hasResults: enhancedTrips.length > 0,
    averagePrice: enhancedTrips.length > 0
      ? (summary.totalPrice / enhancedTrips.length).toFixed(2)
      : '0.00',
    highestPrice: summary.highestPrice.toFixed(2),
    highestRating: summary.highestRating
  };
};

const travel = (req, res) => {
  try {
    const trips = tripRepository.getAllTrips();
    const databaseSummary = tripRepository.getDatabaseSummary();
    const organizedTripData = organizeTrips(trips, req.query);

    res.render('travel', {
      title: 'Travel - Travlr Getaways',
      pageHeading: 'Travel',
      databaseStatus: `Connected to ${databaseSummary.databaseName}`,
      databaseTripCount: databaseSummary.tripCount,
      databaseUpdatedAt: new Date(databaseSummary.updatedAt).toLocaleString('en-US'),
      ...organizedTripData
    });
  } catch (error) {
    res.status(500).render('travel', {
      title: 'Travel - Travlr Getaways',
      pageHeading: 'Travel',
      databaseStatus: 'Database unavailable',
      databaseError: 'Trip data could not be loaded. Please try again later.',
      trips: [],
      searchTerm: '',
      maxPrice: '',
      minRating: '',
      sortBy: 'start-asc',
      totalTrips: 0,
      resultCount: 0,
      hasResults: false,
      averagePrice: '0.00',
      highestPrice: '0.00',
      highestRating: 0
    });
  }
};

module.exports = {
  travel,
  organizeTrips,
  buildSearchText,
  parsePrice,
  parseRating,
  parseTripDays
};

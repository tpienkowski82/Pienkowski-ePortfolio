const tripRepository = require('../database/tripRepository');

const listTrips = (req, res) => {
  res.json({
    metadata: tripRepository.getDatabaseSummary(),
    trips: tripRepository.getAllTrips()
  });
};

const readTrip = (req, res) => {
  const trip = tripRepository.getTripByCode(req.params.code);

  if (!trip) {
    return res.status(404).json({ error: `Trip code ${req.params.code} was not found.` });
  }

  return res.json(trip);
};

const createTrip = (req, res) => {
  const result = tripRepository.createTrip(req.body);

  if (!result.success) {
    return res.status(400).json({ errors: result.errors });
  }

  return res.status(201).json(result.trip);
};

const updateTrip = (req, res) => {
  const result = tripRepository.updateTrip(req.params.code, req.body);

  if (!result.success) {
    return res.status(400).json({ errors: result.errors });
  }

  return res.json(result.trip);
};

const deleteTrip = (req, res) => {
  const result = tripRepository.deleteTrip(req.params.code);

  if (!result.success) {
    return res.status(404).json({ errors: result.errors });
  }

  return res.status(204).send();
};

module.exports = {
  listTrips,
  readTrip,
  createTrip,
  updateTrip,
  deleteTrip
};

const fs = require('fs');
const path = require('path');
const seedTrips = require('../data/trips.json');
const { validateTrip, normalizeTrip } = require('../models/trip');

const databasePath = path.join(__dirname, 'trips-db.json');

const createDefaultStore = () => ({
  metadata: {
    databaseName: 'travlr-trip-database',
    version: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  trips: seedTrips.map(normalizeTrip)
});

const ensureDatabase = () => {
  if (!fs.existsSync(databasePath)) {
    fs.writeFileSync(databasePath, JSON.stringify(createDefaultStore(), null, 2));
  }
};

const readStore = () => {
  ensureDatabase();
  const rawData = fs.readFileSync(databasePath, 'utf8');
  const store = JSON.parse(rawData);

  if (!Array.isArray(store.trips)) {
    throw new Error('Trip database is missing the trips collection.');
  }

  return store;
};

const writeStore = (store) => {
  const updatedStore = {
    ...store,
    metadata: {
      ...store.metadata,
      updatedAt: new Date().toISOString()
    }
  };

  fs.writeFileSync(databasePath, JSON.stringify(updatedStore, null, 2));
  return updatedStore;
};

const getDatabaseSummary = () => {
  const store = readStore();
  return {
    databaseName: store.metadata.databaseName,
    version: store.metadata.version,
    updatedAt: store.metadata.updatedAt,
    tripCount: store.trips.length,
    databasePath
  };
};

const getAllTrips = () => readStore().trips.map(normalizeTrip);

const getTripByCode = (code) => {
  const normalizedCode = String(code || '').trim().toUpperCase();
  return getAllTrips().find((trip) => trip.code === normalizedCode) || null;
};

const createTrip = (tripInput) => {
  const store = readStore();
  const existingCodes = store.trips.map((trip) => trip.code);
  const validation = validateTrip(tripInput, existingCodes);

  if (!validation.isValid) {
    return {
      success: false,
      errors: validation.errors,
      trip: null
    };
  }

  store.trips.push(validation.trip);
  writeStore(store);

  return {
    success: true,
    errors: [],
    trip: validation.trip
  };
};

const updateTrip = (code, tripInput) => {
  const normalizedCode = String(code || '').trim().toUpperCase();
  const store = readStore();
  const tripIndex = store.trips.findIndex((trip) => trip.code === normalizedCode);

  if (tripIndex === -1) {
    return {
      success: false,
      errors: [`Trip code ${normalizedCode} was not found.`],
      trip: null
    };
  }

  const candidateTrip = {
    ...store.trips[tripIndex],
    ...tripInput,
    code: normalizedCode
  };

  const otherCodes = store.trips
    .filter((trip) => trip.code !== normalizedCode)
    .map((trip) => trip.code);
  const validation = validateTrip(candidateTrip, otherCodes);

  if (!validation.isValid) {
    return {
      success: false,
      errors: validation.errors,
      trip: null
    };
  }

  store.trips[tripIndex] = validation.trip;
  writeStore(store);

  return {
    success: true,
    errors: [],
    trip: validation.trip
  };
};

const deleteTrip = (code) => {
  const normalizedCode = String(code || '').trim().toUpperCase();
  const store = readStore();
  const originalCount = store.trips.length;
  store.trips = store.trips.filter((trip) => trip.code !== normalizedCode);

  if (store.trips.length === originalCount) {
    return {
      success: false,
      errors: [`Trip code ${normalizedCode} was not found.`]
    };
  }

  writeStore(store);

  return {
    success: true,
    errors: []
  };
};

const resetDatabase = () => {
  const store = writeStore(createDefaultStore());
  return store.trips;
};

module.exports = {
  databasePath,
  getDatabaseSummary,
  getAllTrips,
  getTripByCode,
  createTrip,
  updateTrip,
  deleteTrip,
  resetDatabase
};

# CS 499 Milestone Four Database Enhancement

This enhancement builds on the Travlr Getaways algorithms version by adding a database-focused layer for trip records.

## Enhancement Summary

- Added `app_server/models/trip.js` to define the trip schema, normalization rules, validation logic, and view model formatting.
- Added `app_server/database/tripRepository.js` as a local file-backed repository that reads and writes `trips-db.json`.
- Added CRUD operations: create, read, update, and delete trip records.
- Added `app_server/controllers/apiTrips.js` and `app_server/routes/api.js` for API endpoints.
- Updated `travel.js` so the travel page retrieves trips from the repository instead of reading seed JSON directly.
- Added validation for required fields, positive numeric prices, valid dates, trip length, resort rating, and duplicate trip codes.
- Added `test/database-check.js` to verify validation and CRUD behavior.

## Running the Project

```bash
npm install
npm start
```

Open:

```text
http://localhost:3000/travel
```

## Testing the Enhancement

```bash
npm test
```

## API Examples

```text
GET    /api/trips
GET    /api/trips/GALR210214
POST   /api/trips
PUT    /api/trips/GALR210214
DELETE /api/trips/GALR210214
```

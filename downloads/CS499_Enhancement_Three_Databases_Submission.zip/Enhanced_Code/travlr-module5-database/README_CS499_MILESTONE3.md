# CS 499 Milestone Three - Algorithms and Data Structures Enhancement

Artifact: Travlr Getaways from CS-465

This enhanced version adds algorithmic processing to the travel page. The original Module Three version rendered trips from `app_server/data/trips.json`. This Milestone Three version adds search, filter, sort, result-count, and average-price logic.

## Key enhanced files

- `app_server/controllers/travel.js`
  - Adds helper functions to parse price, resort rating, and trip length.
  - Adds `organizeTrips()` to search, filter, sort, map, and summarize trip data.
- `app_server/views/travel.hbs`
  - Adds a travel search/filter/sort form.
  - Displays result count and average visible trip price.
  - Displays a no-results message when the algorithm returns no matching trips.
- `public/css/style.css`
  - Adds styling for the new travel controls and summary messages.
- `test/algorithm-check.js`
  - Adds a basic test script for the algorithm helper functions and common search/filter/sort results.

## How to run

```bash
npm install
npm start
```

Open:

```text
http://localhost:3000/travel
```

## How to test the algorithm checks

```bash
npm test
```

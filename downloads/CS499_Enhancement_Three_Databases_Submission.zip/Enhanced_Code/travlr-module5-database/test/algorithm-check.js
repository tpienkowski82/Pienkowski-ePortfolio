const assert = require('assert');
const trips = require('../app_server/data/trips.json');
const { organizeTrips, parsePrice, parseRating, parseTripDays } = require('../app_server/controllers/travel');

assert.strictEqual(parsePrice('799.00'), 799);
assert.strictEqual(parseRating('Blue Lagoon, 4 stars'), 4);
assert.strictEqual(parseTripDays('4 nights / 5 days'), 5);

const priceSorted = organizeTrips(trips, { sortBy: 'price-asc' }).trips;
assert.strictEqual(priceSorted[0].name, 'Gale Reef');

const filtered = organizeTrips(trips, { maxPrice: '1200', minRating: '4' }).trips;
assert.strictEqual(filtered.length, 1);
assert.strictEqual(filtered[0].name, 'Dawson’s Reef');

const searched = organizeTrips(trips, { search: 'claire' }).trips;
assert.strictEqual(searched.length, 1);
assert.strictEqual(searched[0].name, 'Claire’s Reef');

console.log('Algorithm enhancement checks passed.');

const assert = require('assert');
const tripRepository = require('../app_server/database/tripRepository');

const originalTrips = tripRepository.resetDatabase();
assert.strictEqual(originalTrips.length, 3, 'Seed database should include three trips.');

const invalidTrip = tripRepository.createTrip({
  code: 'BAD1',
  name: '',
  perPerson: '-10'
});
assert.strictEqual(invalidTrip.success, false, 'Invalid trip should fail validation.');
assert.ok(invalidTrip.errors.length > 0, 'Invalid trip should return validation errors.');

const createResult = tripRepository.createTrip({
  code: 'TEST260101',
  name: 'Test Reef',
  length: '2 nights / 3 days',
  start: '2026-01-01T08:00:00Z',
  resort: 'Test Resort, 4 stars',
  perPerson: '999.00',
  image: 'reef1.jpg',
  description: ['Temporary database test record.']
});
assert.strictEqual(createResult.success, true, 'Valid trip should be created.');

const readResult = tripRepository.getTripByCode('TEST260101');
assert.strictEqual(readResult.name, 'Test Reef', 'Created trip should be readable by code.');

const updateResult = tripRepository.updateTrip('TEST260101', { perPerson: '899.00' });
assert.strictEqual(updateResult.success, true, 'Existing trip should be updatable.');
assert.strictEqual(updateResult.trip.perPerson, '899.00', 'Updated trip should store normalized price.');

const deleteResult = tripRepository.deleteTrip('TEST260101');
assert.strictEqual(deleteResult.success, true, 'Existing trip should be deletable.');
assert.strictEqual(tripRepository.getTripByCode('TEST260101'), null, 'Deleted trip should not be found.');

tripRepository.resetDatabase();
console.log('Database enhancement checks passed.');

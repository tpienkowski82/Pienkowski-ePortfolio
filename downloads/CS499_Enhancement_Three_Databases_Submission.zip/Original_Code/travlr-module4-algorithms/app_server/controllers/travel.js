const trips = require('../data/trips.json');

/**
 * Convert the price field from the trip JSON file into a number so it can be
 * compared and sorted reliably.
 * @param {string|number} price
 * @returns {number}
 */
const parsePrice = (price) => Number.parseFloat(price) || 0;

/**
 * Extract the star rating from the resort string, such as "Emerald Bay, 3 stars".
 * @param {string} resort
 * @returns {number}
 */
const parseRating = (resort = '') => {
  const ratingMatch = resort.match(/(\d+)\s*stars?/i);
  return ratingMatch ? Number.parseInt(ratingMatch[1], 10) : 0;
};

/**
 * Extract the number of trip days from a length string, such as
 * "4 nights / 5 days". This supports sorting by trip length.
 * @param {string} length
 * @returns {number}
 */
const parseTripDays = (length = '') => {
  const dayMatch = length.match(/(\d+)\s*days?/i);
  return dayMatch ? Number.parseInt(dayMatch[1], 10) : 0;
};

/**
 * Build a searchable string for each trip. Combining the searchable fields once
 * keeps the filter logic readable and makes it easier to expand later.
 * @param {object} trip
 * @returns {string}
 */
const buildSearchText = (trip) => [
  trip.code,
  trip.name,
  trip.length,
  trip.start,
  trip.resort,
  trip.perPerson,
  ...(trip.description || [])
].join(' ').toLowerCase();

/**
 * Apply search, filter, and sort choices to the trip data.
 * This enhancement demonstrates algorithms and data structures by using array
 * filtering, searching, sorting, mapping, and summary reduction.
 * @param {Array<object>} tripData
 * @param {object} query
 * @returns {object}
 */
const organizeTrips = (tripData, query) => {
  const searchTerm = (query.search || '').trim().toLowerCase();
  const maxPrice = Number.parseFloat(query.maxPrice);
  const minRating = Number.parseInt(query.minRating, 10);
  const sortBy = query.sortBy || 'start-asc';

  let filteredTrips = [...tripData];

  if (searchTerm) {
    filteredTrips = filteredTrips.filter((trip) => buildSearchText(trip).includes(searchTerm));
  }

  if (!Number.isNaN(maxPrice)) {
    filteredTrips = filteredTrips.filter((trip) => parsePrice(trip.perPerson) <= maxPrice);
  }

  if (!Number.isNaN(minRating)) {
    filteredTrips = filteredTrips.filter((trip) => parseRating(trip.resort) >= minRating);
  }

  const sortOptions = {
    'start-asc': (a, b) => new Date(a.start) - new Date(b.start),
    'price-asc': (a, b) => parsePrice(a.perPerson) - parsePrice(b.perPerson),
    'price-desc': (a, b) => parsePrice(b.perPerson) - parsePrice(a.perPerson),
    'name-asc': (a, b) => a.name.localeCompare(b.name),
    'rating-desc': (a, b) => parseRating(b.resort) - parseRating(a.resort),
    'length-asc': (a, b) => parseTripDays(a.length) - parseTripDays(b.length)
  };

  const sortFunction = sortOptions[sortBy] || sortOptions['start-asc'];
  filteredTrips.sort(sortFunction);

  const enhancedTrips = filteredTrips.map((trip) => ({
    ...trip,
    priceValue: parsePrice(trip.perPerson),
    rating: parseRating(trip.resort),
    tripDays: parseTripDays(trip.length),
    formattedStart: new Date(trip.start).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    })
  }));

  const summary = enhancedTrips.reduce((totals, trip) => {
    totals.totalPrice += trip.priceValue;
    totals.highestPrice = Math.max(totals.highestPrice, trip.priceValue);
    totals.highestRating = Math.max(totals.highestRating, trip.rating);
    return totals;
  }, {
    totalPrice: 0,
    highestPrice: 0,
    highestRating: 0
  });

  return {
    trips: enhancedTrips,
    searchTerm: query.search || '',
    maxPrice: query.maxPrice || '',
    minRating: query.minRating || '',
    sortBy,
    totalTrips: tripData.length,
    resultCount: enhancedTrips.length,
    hasResults: enhancedTrips.length > 0,
    averagePrice: enhancedTrips.length > 0
      ? (summary.totalPrice / enhancedTrips.length).toFixed(2)
      : '0.00',
    highestPrice: summary.highestPrice.toFixed(2),
    highestRating: summary.highestRating
  };
};

const travel = (req, res) => {
  const organizedTripData = organizeTrips(trips, req.query);

  res.render('travel', {
    title: 'Travel - Travlr Getaways',
    pageHeading: 'Travel',
    ...organizedTripData
  });
};

module.exports = {
  travel,
  organizeTrips,
  parsePrice,
  parseRating,
  parseTripDays
};

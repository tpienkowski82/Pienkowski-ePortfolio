const express = require('express');
const path = require('path');
const hbs = require('hbs');

const indexRouter = require('./app_server/routes/index');

const app = express();

// Configure Handlebars view engine for the MVC application structure.
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Serve static assets such as CSS and images from /public.
app.use(express.static(path.join(__dirname, 'public')));

// Register application routes.
app.use('/', indexRouter);

// Catch 404 errors.
app.use((req, res) => {
  res.status(404).send('404: Page not found');
});

module.exports = app;

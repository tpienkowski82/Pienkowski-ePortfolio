const express = require('express');
const path = require('path');

const router = express.Router();
const ctrlTravel = require('../controllers/travel');

// Route for the original landing page.
router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/index.html'));
});

// Routes for the travel page rendered through the HBS template engine.
router.get('/travel', ctrlTravel.travel);
router.get('/travel.html', ctrlTravel.travel);

module.exports = router;

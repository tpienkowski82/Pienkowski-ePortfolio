# Travlr Getaways - Module Two MVC/HBS Setup

This project refactors the Travlr Getaways static website into an Express application that uses an MVC-style structure and the HBS templating engine for the travel page.

## Module Two structure

```text
travlr-module2-mvc/
├── app_server/
│   ├── controllers/
│   │   └── travel.js
│   ├── routes/
│   │   └── index.js
│   └── views/
│       └── travel.hbs
├── bin/
│   └── www
├── public/
│   ├── css/
│   ├── images/
│   ├── index.html
│   ├── rooms.html
│   ├── meals.html
│   ├── news.html
│   ├── about.html
│   └── contact.html
├── .gitignore
├── app.js
├── package.json
└── README.md
```

## What changed for Module Two

- Added `app_server` to organize server-side MVC code.
- Added `app_server/controllers/travel.js` to hold the travel page data and rendering logic.
- Added `app_server/routes/index.js` to register the home and travel routes.
- Converted `public/travel.html` into `app_server/views/travel.hbs`.
- Added HBS directives such as `{{title}}`, `{{pageHeading}}`, `{{#each trips}}`, and `{{#each paragraphs}}`.
- Updated `app.js` to register the HBS view engine and use the app_server routes.

## Run the project

```bash
npm install
npm start
```

Then open:

```text
http://localhost:3000
```

To test the HBS-rendered page, open:

```text
http://localhost:3000/travel
```

or click the Travel link from the homepage.

## Git branch

Module Two work should be pushed to a branch named:

```text
module2
```
